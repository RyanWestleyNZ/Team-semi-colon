﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temisemicolon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                //If both login fields are not null, check the details against the database to find a matching Username and Password
                //Shows messageboxes for unsuccessful login and empty text boxes
                if (tbxUsername.Text != "" & tbxPassword.Text != "")
                {
                    DatabaseDataSetTableAdapters.StudentsTableAdapter login = new DatabaseDataSetTableAdapters.StudentsTableAdapter();
                    DatabaseDataSet.StudentsDataTable dt = login.GetDataByStudentIDPassword(int.Parse(tbxUsername.Text), tbxPassword.Text);
                    //add code to check if the login person is a lecturer

                    //Upon successful login, the login panel disappears and is replaced with a welcome message
                    if (dt.Rows.Count > 0)
                    {
                        if (chkAutoLogin.Checked)
                        {
                            FileManager.SaveLoginDetails(tbxUsername.Text, tbxPassword.Text);
                        }
                        lblWelcome.Text = "Welcome, " + dt.Rows[0]["First_Name"].ToString() + " " + dt.Rows[0]["Last_Name"].ToString();
                        pnlLogin.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Incorrect username and password.", "Error");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter your username and password.", "Error");
                }
            }
            catch(Exception)
            {
             
            }
        }

        private void tbxUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Logs you in when you press the enter key
            if(e.KeyChar == (char)13)
            {
                btnLogin.PerformClick();
            }
        }

        private void tbxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Also logs you in when you press the enter key, unsurprisingly
            if (e.KeyChar == (char)13)
            {
                btnLogin.PerformClick();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] loginDetails = FileManager.LoadLoginDetails();
            tbxUsername.Text = loginDetails[0];
            tbxPassword.Text = loginDetails[1];
            btnLogin.PerformClick();
        }
    }
}
