<?php
   include("config.php");
   $papers = mysqli_query($db, "SELECT * from courses");
   while($row = mysqli_fetch_array($papers))
   {
	   echo $row['Paper_ID'] . "<br>";
   }
   ?>