<?php
	function getpapers(){
		
	}
	
	function editpaper(){
		
	}
	
	function addpaper(){
		
	}
	
	function deletepaper(){
		
	}
	
	function filter(){
		
	}