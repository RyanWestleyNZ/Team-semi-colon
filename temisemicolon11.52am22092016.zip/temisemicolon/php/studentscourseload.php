<?php
require 'medoo.min.php';
require 'config.php';
$database = new Medoo();

if (isset($_GET["action"])) {
	switch($_GET["action"]) {
		case 'pageload':
			
			$html = "";
			$html.= "<table>";
			$html.= "<th>&nbsp;</th><th>Development</th><th>Information</th><th>Technology</th>";
			$html.="<tr><td rowspan='2'>Year 1</td> <td>";
			
			//Development, Y1 S1
			$data = mysqli_query($db,"select * from dyear1semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:blue;'>";
				} else{
					$html.="style='background:skyblue;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Information, Y1 S1
			$data = mysqli_query($db,"select * from iyear1semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:yellow;'>";
				} else{
					$html.="style='background:lightyellow;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
						
			//Technology, Y1 S1
			$data = mysqli_query($db,"select * from tyear1semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:red;'>";
				} else{
					$html.="style='background:pink;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td></tr><tr><td>";
			
			//Development, Y1 S2
			$data = mysqli_query($db,"select * from dyear1semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:blue;'>";
				} else{
					$html.="style='background:skyblue;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Information, Y1 S2
			$data = mysqli_query($db,"select * from iyear1semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:yellow;'>";
				} else{
					$html.="style='background:lightyellow;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";

			//Technology, Y1 S2
			$data = mysqli_query($db,"select * from tyear1semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:red;'>";
				} else{
					$html.="style='background:pink;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			
			$html.="<tr><td rowspan='2'>Year 2</td> <td>";
			
			//Development, Y2 S1
			$data = mysqli_query($db,"select * from dyear2semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:blue;'>";
				} else{
					$html.="style='background:skyblue;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Information, Y2 S1
			$data = mysqli_query($db,"select * from iyear2semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:yellow;'>";
				} else{
					$html.="style='background:lightyellow;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Technology, Y2 S1
			$data = mysqli_query($db,"select * from tyear2semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:red;'>";
				} else{
					$html.="style='background:pink;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td></tr><tr><td>";
			
			//Development, Y2 S2
			$data = mysqli_query($db,"select * from dyear2semseter2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:blue;'>";
				} else{
					$html.="style='background:skyblue;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Information, Y2 S2
			$data = mysqli_query($db,"select * from iyear2semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:yellow;'>";
				} else{
					$html.="style='background:lightyellow;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Technology, Y2 S2
			$data = mysqli_query($db,"select * from tyear2semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:red;'>";
				} else{
					$html.="style='background:pink;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			$html.="</td></tr><tr><td rowspan='2'>Year 3</td> <td>";
			
			//Development, Y3 S1
			$data = mysqli_query($db,"select * from dyear3semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:blue;'>";
				} else{
					$html.="style='background:skyblue;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Information, Y3 S1
			$data = mysqli_query($db,"select * from iyear3semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:yellow;'>";
				} else{
					$html.="style='background:lightyellow;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Technology, Y3 S1
			$data = mysqli_query($db,"select * from tyear3semester1");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:red;'>";
				} else{
					$html.="style='background:pink;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td></tr><tr><td>";
			
			//Development, Y3 S2
			$data = mysqli_query($db,"select * from dyear3semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:blue;'>";
				} else{
					$html.="style='background:skyblue;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Information, Y3 S2
			$data = mysqli_query($db,"select * from iyear3semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:yellow;'>";
				} else{
					$html.="style='background:lightyellow;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td><td>";
			
			//Technology, Y3 S2
			$data = mysqli_query($db,"select * from tyear3semester2");
			foreach ($data as $value) {
				$html.="<a href='#'><div class='paper' ";
				if ($value['Compulsory']==1) {
					$html.="style='background:red;'>";
				} else{
					$html.="style='background:pink;'>";
				}
				$html.=$value['Paper_Name'] . "<br>"
					 . $value['Paper_ID']
					 . "</div></a>";
			}
			$html.="</td></tr></table>";
			
			echo $html;
			break;
		}
	}