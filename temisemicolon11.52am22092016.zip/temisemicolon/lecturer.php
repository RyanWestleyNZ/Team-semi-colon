<?php
	include('session.php');
?>

<html>
	<head>
	<title>Lecturer Admin</title>
	<link href="css/lecturer.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<div id="header">
		<IMG class="displayed" src="img/UCOLNew.jpg" alt="Logo">
		<br><br>
		<h1>Welcome, <?php echo $login_session; ?></h1> <button id="logout"><a href="logout.php">Sign Out</a></button><button href="#" class="newpaper">Add New Paper</button>
		
		</div>
		<div class="courses">
		<p>Loading courses...</p>
		</div>
		
		<div class="right">
			
			<div class="edit">
				&nbsp;
			</div>
		</div>
		
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/main.js" type="text/javascript"></script>
	</body>
</html>