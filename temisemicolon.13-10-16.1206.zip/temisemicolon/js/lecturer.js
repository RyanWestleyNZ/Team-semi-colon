$(document).ready(function() {
	//Trigger to fetch paper on pageload
	$.get("php/lecturercontroller.php?action=pageload", function(data) {
		$('.courses').html(data);
	});
	
	//Trigger to bring up the paper editing form
	$(".courses").on("click","a.editpaper",function() {
		$.get("php/lecturercontroller.php?action=edit&value=" + $(this).attr("data-id"), function(data) {
			$('.edit').html(data);
		});
		return false;
	});
	
	//Trigger to bring up the paper creation form
	$("body").on("click","button.newpaper",function() {
		$.get("php/lecturercontroller.php?action=new", function(data) {
			$('.edit').html(data);
		});
		return false;
	});
	
	//Trigger to delete an existing paper
	$(".courses").on("click","a.deletepaper",function() {
		if (confirm('Are you sure you want to delete the paper?')) {
		$.get("php/lecturercontroller.php?action=delete&value=" + $(this).attr("data-id"), function(data) {
			alert(data);
			location.reload();
		});
		} else {
		// Do nothing
		}
		return false;
	});
	
	//Trigger to update an existing paper (not done yet)
	$(".edit").on("click","button.updateexisting",function() {
		if (confirm('Are you sure you want to make these changes?')) {
		$.post("php/lecturercontroller.php?action=update&value=" + $(this).attr("data-id"), $('form').serialize(), function(data) {
			alert(data);
			location.reload();
		});
		} else {
		// Do nothing
		}
		return false;
	});
	
	//Trigger to save a new paper
	$(".edit").on("click","button.savenew",function() {
		$.post("php/lecturercontroller.php?action=create", $('form').serialize(), function(data) {
			alert(data);
			location.reload();
		});
		return false;
	});

});