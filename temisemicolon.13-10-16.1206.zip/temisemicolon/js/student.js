document.addEventListener('DOMContentLoaded', function() {
	$.get("php/studentcontroller.php?action=pageload", function(data) {
		$('.courses').html(data);
	});
});