<?php
   include('session.php');
?>
<html">
   
   <head>
		<link href="css/student.css" rel="stylesheet" type="text/css">
		<title>Welcome </title>
   </head>
   
   <body> 
		<div id="header">
			<IMG class="displayed" src="img/UCOLNew.jpg" alt="Logo">
					<br><br>
		<h1>Welcome, <?php echo $login_session; ?></h1> <button id="logout"><a href="logout.php">Sign Out</a></button>
		<br><br>
		</div>
		
		<div class="courses">
		<p>Loading courses...</p>
		</div>
		
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/student.js" type="text/javascript"></script>
   </body>
   
</html>