<?php
require 'medoo.min.php';
$database = new Medoo();

$data =$database->query("select id, name from city")->fetchAll();
			
			$html = "";
			$html.= "<table>";
			$html.= "<th>Name</th><th>Show</th>";
			
			foreach ($data as $value)
			{
				$html.= "<tr>"
						. "<td>" . $value['name'] . "</td>"
						. "<td><a href='#' data-id='" . $value['id'] . "'>show</a></td>"
						. "</tr>";
			}
			$html.="</table>";
			
			echo $html;
			break;