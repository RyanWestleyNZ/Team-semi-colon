<?php
   // include('session.php');
// ?>
<html">
   <link rel="stylesheet" type="text/css" href="css/lecturerprettiness.css">
   <head>
      <title>Welcome</title>
   </head>
   
   <body>
	<IMG class="displayed" src="pics/ucol-logo.jpg" alt="Logo"> 
    
	<p>Welcome Lecturer!</p> 
	
	<input type = "submit" id="button" value = " Log Out "a href = "logout.php" />
	
	<div class="container_1">
		<div class="container_2">
	
		</div>
	</div>

	
	

   </body>
   
</html>