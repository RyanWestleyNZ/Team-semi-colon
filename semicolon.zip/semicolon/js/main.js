document.addEventListener('DOMContentLoaded', function() {
    $.get("php/courseload.php" + $(this).text(), function(data) {
			$('.courses').html(data);
}, false);