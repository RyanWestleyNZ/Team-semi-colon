<?php
require 'medoo.min.php';
require 'config.php';
$database = new Medoo();

if (isset($_GET["action"])) {
	switch($_GET["action"]) {
		case 'pageload':
			$data =$database->query("select * from courses")->fetchAll();
			
			$html = "";
			$html.= "<table class='lol'>";
			$html.= "<th>Paper ID</th><th>Paper Name</th><th>Pre-Requisite</th><th>Compulsory</th><th>Description</th><th>Semester Available</th><th>Credits</th><th>Edit</th><th>Delete</th>";
			
			foreach ($data as $value)
			{
				$html.= "<tr>"
						. "<td>" . $value['Paper_ID'] . "</td>"
						. "<td>" . $value['Paper_Name'] . "</td>"
						. "<td>" . $value['Pre-Requisite'] . "</td>"
						. "<td>" . $value['Compulsory'] . "</td>"
						. "<td>" . $value['Description'] . "</td>"
						. "<td>" . $value['Semester_Available'] . "</td>"
						. "<td>" . $value['Credits'] . "</td>"
						. "<td><a href='#' class='editpaper' data-id='" . $value['Paper_ID'] . "'>Edit</a></td> "
						. "<td><a href='lecturer.php' class='deletepaper' data-id='" . $value['Paper_ID'] . "'>Delete</a></td>"
						. "</tr>";
			}
			$html.="</table>";
			
			echo $html;
			break;
			
		case 'edit':
			$data = $database->select("courses", [
				"Paper_ID",
				"Paper_Name",
				"Pre-Requisite",
				"Compulsory",
				"Description",
				"Semester_Available",
				"Credits"
					], [
				"Paper_ID[=]" => $_GET['value']
			]);
			
			foreach ($data as $value)
			{
				$form = "<form>";
				$form.= "<label>Paper ID:</label><br><input type='text' id='Paper_ID' name='Paper_ID' value='".$value['Paper_ID']."'><br>";
				$form.= "<label>Paper Name:</label><br><input type='text' id='Paper_Name' name='Paper_Name' value='".$value['Paper_Name']."'><br>";
				$form.= "<label>Pre-Requisite:</label><br><input type='text' id='Pre-Requisite' name='Pre-Requisite' value='".$value['Pre-Requisite']."'><br>";
				$form.= "<label>Compulsory:</label><br><input type='text' id='Compulsory' name='Compulsory' value='".$value['Compulsory']."'><br>";
				$form.= "<label>Description:</label><br><input type='text' id='Description' name='Description' value='".$value['Description']."'><br>";
				$form.= "<label>Semester Available:</label><br><input type='text' id='Semester_Available' name='Semester_Available' value='".$value['Semester_Available']."'><br>";
				$form.= "<label>Credits:</label><br><input type='text' id='Credits' name='Credits' value='".$value['Credits']."'><br>";
				$form.= "<button href='#' data-id='".$value['Paper_ID']."'>Save</button>";
				$form.= "</form>";
			}
			
			echo $form;
			break;
			
		case 'new':
			$form = "<form>";
			$form.= "<label>Paper ID:</label><br><input type='text' id='Paper_ID' name='Paper_ID'><br>";
			$form.= "<label>Paper Name:</label><br><input type='text' id='Paper_Name' name='Paper_Name'><br>";
			$form.= "<label>Pre-Requisite:</label><br><input type='text' id='Pre-Requisite' name='Pre-Requisite'><br>";
			$form.= "<label>Compulsory:</label><br><input type='text' id='Compulsory' name='Compulsory'><br>";
			$form.= "<label>Description:</label><br><input type='text' id='Description' name='Description'><br>";
			$form.= "<label>Semester Available:</label><br><input type='text' id='Semester_Available' name='Semester_Available'><br>";
			$form.= "<label>Credits:</label><br><input type='text' id='Credits' name='Credits' value='><br>";
			$form.= "<button href='#' class='savenew'>Save</button>";
			$form.= "</form>";
			
			echo $form;
			break;
			
		case 'delete':
	
		// $paperid = $_GET['value'];
		// mysqli_query($db, "delete from courses where Paper_ID = $paperid");
	function delete ($id) {
	$id = $_POST['id'];	
	if (mysqli_connect_errno(db))
		{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
	$delete = "DELETE FROM courses WHERE id = $id";
	
	if (mysqli_query($db, $delete)) {
    echo "Record deleted successfully ";
	} else {
    echo "Error deleting record: " . mysqli_error($db);
	
	mysqli_close($db);
		echo $form;
		break;
	}
	}
}

}