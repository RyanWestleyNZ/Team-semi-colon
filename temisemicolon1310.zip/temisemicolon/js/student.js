document.addEventListener('DOMContentLoaded', function() {
	$.get("php/studentscourseload.php?action=pageload", function(data) {
		$('.courses').html(data);
	});
});