document.addEventListener('DOMContentLoaded', function() {
	$.get("php/courseload.php?action=pageload", function(data) {
		$('.courses').html(data);
	});
});

$(document).ready(function() {
	
	$(".courses").on("click","a.editpaper",function() {
		$.get("php/courseload.php?action=edit&value=" + $(this).attr("data-id"), function(data) {
			$('.edit').html(data);
		});
		return false;
	});
	
	$(".right").on("click","a.new",function() {
		$.get("php/courseload.php?action=new", function(data) {
			$('.edit').html(data);
		});
		return false;
	});
	
	// $(".courses").on("click","a.deletepaper",function() {
		// if (confirm('Are you sure you want to delete the paper?')) {
		// alert("Wop doesn't do this yet");
		// $.get("php/courseload.php?action=delete", function(data) {
			// $('.delete').html(data);
		// }
		// )
	// else {
		// // Do nothing!
	// }
		// return true;
	// });

});