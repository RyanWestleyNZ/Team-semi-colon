<?php
   include('session.php');
?>
<html">
   
   <head>
		<link href="css/student.css" rel="stylesheet" type="text/css">
		<title>Welcome </title>
   </head>
   
   <body> 
		<IMG class="displayed" src="img/ucol-logo.jpg" alt="Logo">
		<h1>Welcome, <?php echo $login_session; ?></h1>
		<p><a href="logout.php"><button class="logout">Log Out</button></a></p></div>
		
		<div class="courses">
		<p>Loading courses...</p>
		</div>
		
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/student.js" type="text/javascript"></script>
   </body>
   
</html>