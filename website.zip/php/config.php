<?php
	define("DB_SERVER", "localhost");
	define("USERNAME", "root");
	define("PASSWORD", "");
	define("DB_NAME", "whatevertheycallit");
?>

