<html>
  <head>
	<title>Password test, page 2</title>
  <head>


  <body>

	<?php 
		 $name  = $_POST['realname'];
		 $pass  = $_POST['mypassword']; 
		 echo $name;
	  ?>

	  <br>

	  <?php
		 echo $pass;
	  ?>	<br>
  
  </body>
</html>