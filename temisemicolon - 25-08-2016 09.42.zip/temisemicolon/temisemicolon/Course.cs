﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace temisemicolon
{
    public class Course
    {
        private string courseID;
        private string name;

        public string CourseID
        {
            get
            {
                return CourseID;
            }

            set
            {
                CourseID = value;
            }
        }

        public string Name
        {
            get
            {
                return Name;
            }

            set
            {
                Name = value;
            }
        }

    }
}
