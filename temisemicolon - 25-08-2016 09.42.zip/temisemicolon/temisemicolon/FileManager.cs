﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace temisemicolon
{
    static class FileManager
    {
        public static void SaveLoginDetails(string u, string p)
        {
            //Creates new StreamWriter that saves to a text file
            StreamWriter sw = new StreamWriter("autologin.txt");
            //Writes the strings u and p to the text file and then disposes the streamwriter
            sw.WriteLine(u);
            sw.WriteLine(p);
            sw.Dispose();
        }

        public static string[] LoadLoginDetails()
        {
            //Creates a string array
            string[] login = { "\0", "\0" };
            //Creates a new StreamReader that reads from the text file
            //and assigns the values of each line to the string array
            //Returns the string array
            //If there is an error, returns a blank array
            try
            {
                StreamReader sr = new StreamReader("autologin.txt");
                login[0] = sr.ReadLine();
                login[1] = sr.ReadLine();
                sr.Dispose();
            }
            catch(Exception)
            {

            }
            return login;
        }
    }
}
