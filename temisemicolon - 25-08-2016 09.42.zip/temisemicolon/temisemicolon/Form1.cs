﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temisemicolon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                //If both login fields are not null, check the details against the database to find a matching Username and Password
                if (tbxUsername.Text != "" & tbxPassword.Text != "")
                {
                    DatabaseDataSetTableAdapters.StudentsTableAdapter loginStudent = new DatabaseDataSetTableAdapters.StudentsTableAdapter();
                    DatabaseDataSet.StudentsDataTable dts = loginStudent.GetDataByStudentIDPassword(int.Parse(tbxUsername.Text), tbxPassword.Text);
                    //add code to check if the login person is a lecturer

                    //Upon successful login, the login panel disappears and is replaced with a welcome message
                    //If someone selects "Keep Me Logged In", the details are saved to the autologin text file for later
                    if (dts.Rows.Count > 0)
                    {
                        if (chkAutoLogin.Checked)
                        {
                            FileManager.SaveLoginDetails(tbxUsername.Text, tbxPassword.Text);
                        }
                        lblWelcome.Text = "Welcome, " + dts.Rows[0]["First_Name"].ToString() + " " + dts.Rows[0]["Last_Name"].ToString();
                        pnlLogin.Visible = false;
                        pnlMainStudent.Visible = true;
                    }
                    //If the login returns no students, check the lecturers table instead. same code
                    else
                    {
                        DatabaseDataSetTableAdapters.LecturersTableAdapter loginLecturer = new DatabaseDataSetTableAdapters.LecturersTableAdapter();
                        DatabaseDataSet.LecturersDataTable dtl = loginLecturer.GetDataByLecturerIDPassword(int.Parse(tbxUsername.Text), tbxPassword.Text);

                        if (dtl.Rows.Count > 0)
                        {
                            if (chkAutoLogin.Checked)
                            {
                                FileManager.SaveLoginDetails(tbxUsername.Text, tbxPassword.Text);
                            }
                            lblWelcome.Text = "Welcome, " + dtl.Rows[0]["First_Name"].ToString() + " " + dtl.Rows[0]["Last_Name"].ToString();
                            pnlLogin.Visible = false;
                            pnlMainLecturer.Visible = true;
                        }

                        //Shows messageboxes for unsuccessful login and empty text boxes
                        else
                        {
                            MessageBox.Show("Incorrect username and password.", "Error");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter your username and password.", "Error");
                }
            }
            catch(Exception)
            {
             
            }
        }

        private void tbxUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Logs you in when you press the enter key
            if(e.KeyChar == (char)13)
            {
                btnLogin.PerformClick();
            }
        }

        private void tbxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Also logs you in when you press the enter key, unsurprisingly
            if (e.KeyChar == (char)13)
            {
                btnLogin.PerformClick();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet.Courses' table. You can move, or remove it, as needed.
            this.coursesTableAdapter.Fill(this.databaseDataSet.Courses);
            //upon loading the form, the program takes login details from the autologin file.
            //If there's anything in the file, it attempts to log the user in.
            //it also hides the panels that have content in them depending on the login entered (student and lecturer panels)
            pnlMainLecturer.Visible = false;
            pnlMainStudent.Visible = false;
            string[] loginDetails = FileManager.LoadLoginDetails();
            tbxUsername.Text = loginDetails[0];
            tbxPassword.Text = loginDetails[1];
            if (loginDetails[0] != "\0")
            {
                btnLogin.PerformClick();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //when the "Logout" button is pressed, the auto-login details are removed and the form is set back to its default.
            //the login panel is displayed again
            FileManager.SaveLoginDetails("\0", "\0");
            lblWelcome.Text = "Welcome";
            pnlMainLecturer.Visible = false;
            pnlMainStudent.Visible = false;
            pnlLogin.Visible = true;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {

        }
    }
}
