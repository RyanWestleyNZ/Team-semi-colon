<?php
require 'medoo.min.php';
require 'config.php';
$database = new Medoo();

if (isset($_GET["action"])) {
	switch($_GET["action"]) {
		case 'pageload':
			$data =$database->query("select * from courses")->fetchAll();
			
			$html = "";
			$html.= "<table>";
			
			foreach ($data as $value)
			{
				$html.= "<tr>"
						. "<td>" . $value['Paper_ID'] . "</td>"
						. "<td>" . $value['Paper_Name'] . "</td>"
						. "<td>" . $value['Pre-Requisite'] . "</td>"
						. "<td>" . $value['Compulsory'] . "</td>"
						. "<td>" . $value['Description'] . "</td>"
						. "<td>" . $value['Semester_Available'] . "</td>"
						. "<td>" . $value['Credits'] . "</td>"
						. "</tr>";
			}
			$html.="</table>";
			
			echo $html;
			break;
			
			foreach ($data as $value)
			{
				$form = "<form>";
				$form.= "<input type='text' id='Paper_ID' name='Paper_ID' value='".$value['Paper_ID']."'><br>";
				$form.= "<input type='text' id='Paper_Name' name='Paper_Name' value='".$value['Paper_Name']."'><br>";
				$form.= "<input type='text' id='Pre-Requisite' name='Pre-Requisite' value='".$value['Pre-Requisite']."'><br>";
				$form.= "<input type='text' id='Compulsory' name='Compulsory' value='".$value['Compulsory']."'><br>";
				$form.= "<input type='text' id='Description' name='Description' value='".$value['Description']."'><br>";
				$form.= "<input type='text' id='Semester_Available' name='Semester_Available' value='".$value['Semester_Available']."'><br>";
				$form.= "<input type='text' id='Credits' name='Credits' value='".$value['Credits']."'><br>";
				$form.= "</form>";
			}
			
			echo $form;
			break;
	}

}

