<?php
   include('session.php');
?>
<html">
   
   <head>
      <title>Welcome </title>
	  <link href="css/student.css" rel="stylesheet" type="text/css">
   </head>
   
   <body>
      <h1>Welcome, <?php echo $login_session; ?></h1>
	  <p>aaaaa</p>
      <h2><a href = "logout.php">Sign Out</a></h2>
	  
	  	<div class="courses">
		<p>Loading courses...</p>
		</div>
	  
	     <script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/SMain.js" type="text/javascript"></script>
   </body>
</html>