document.addEventListener('DOMContentLoaded', function() {
	$.get("php/student_course_load.php?action=pageload", function(data) {
		$('.courses').html(data);
	});


});