<?php
	define("DB_SERVER", "localhost");
	define("USERNAME", "root");
	define("PASSWORD", "");
	define("DB_NAME", "ucol");
	$db = mysqli_connect(DB_SERVER,USERNAME,PASSWORD,DB_NAME);
